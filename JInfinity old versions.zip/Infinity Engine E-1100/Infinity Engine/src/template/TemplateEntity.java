package template;

import static org.lwjgl.opengl.GL11.GL_COMPILE;
import static org.lwjgl.opengl.GL11.GL_NEAREST;
import static org.lwjgl.opengl.GL11.GL_QUADS;
import static org.lwjgl.opengl.GL11.GL_RGBA;
import static org.lwjgl.opengl.GL11.GL_TEXTURE_2D;
import static org.lwjgl.opengl.GL11.GL_TEXTURE_MAG_FILTER;
import static org.lwjgl.opengl.GL11.GL_TEXTURE_MIN_FILTER;
import static org.lwjgl.opengl.GL11.GL_UNSIGNED_BYTE;
import static org.lwjgl.opengl.GL11.glBegin;
import static org.lwjgl.opengl.GL11.glBindTexture;
import static org.lwjgl.opengl.GL11.glCallList;
import static org.lwjgl.opengl.GL11.glDeleteLists;
import static org.lwjgl.opengl.GL11.glDeleteTextures;
import static org.lwjgl.opengl.GL11.glEnd;
import static org.lwjgl.opengl.GL11.glEndList;
import static org.lwjgl.opengl.GL11.glGenLists;
import static org.lwjgl.opengl.GL11.glGenTextures;
import static org.lwjgl.opengl.GL11.glLoadIdentity;
import static org.lwjgl.opengl.GL11.glNewList;
import static org.lwjgl.opengl.GL11.glTexCoord2d;
import static org.lwjgl.opengl.GL11.glTexImage2D;
import static org.lwjgl.opengl.GL11.glTexParameteri;
import static org.lwjgl.opengl.GL11.glVertex3d;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;

import org.lwjgl.BufferUtils;
import org.lwjgl.opengl.Display;

import de.matthiasmann.twl.utils.PNGDecoder;
import de.matthiasmann.twl.utils.PNGDecoder.Format;
import engine.A_Entity;

//Eligible for complete removal.
//Quantity of sequences eligible for changes: Whole class.
//Description: Template of entity.
public class TemplateEntity extends A_Entity{
	public int mesh;
	public int texture;
	String texturePath;
	public double x,y,z,size;
	public TemplateEntity(int ID){
		id=ID;
		texturePath = "res/TemplateTexture.png";
		initTexture();
		size=1;
		refactor(0,0,-3,1);
	}
	public void draw(){
		glBindTexture(GL_TEXTURE_2D, texture);
        glCallList(mesh);
        glLoadIdentity();
	}
	public void destroy(){
		glDeleteTextures(texture);
        glDeleteLists(mesh, 1);
	}
	public void refactor(double x1,double y1,double z1,double size1){
		x=x1;
		y=y1;
		z=z1;
		size=size1;
    	mesh = glGenLists(1);
		glNewList(mesh, GL_COMPILE);
        glBegin(GL_QUADS);
        
        glTexCoord2d(0, 0);
        glVertex3d(x, y, z);
        glTexCoord2d(0, 1);
        glVertex3d(x+size, y, z);
        glTexCoord2d(1, 1);
        glVertex3d(x+size, y+size, z);
        glTexCoord2d(1, 0);
        glVertex3d(x, y+size, z);
        
        glTexCoord2d(0, 0);
        glVertex3d(x+size, y, z);
        glTexCoord2d(0, 1);
        glVertex3d(x+size, y, z-size);
        glTexCoord2d(1, 1);
        glVertex3d(x+size, y+size, z-size);
        glTexCoord2d(1, 0);
        glVertex3d(x+size, y+size, z);
		
        glTexCoord2d(0, 0);
        glVertex3d(x, y+size, z-size);
        glTexCoord2d(0, 1);
        glVertex3d(x+size, y+size, z-size);
        glTexCoord2d(1, 1);
        glVertex3d(x+size, y, z-size);
        glTexCoord2d(1, 0);
        glVertex3d(x, y, z-size);

        glTexCoord2d(0, 0);
        glVertex3d(x, y+size, z);
        glTexCoord2d(0, 1);
        glVertex3d(x, y+size, z-size);
        glTexCoord2d(1, 1);
        glVertex3d(x, y, z-size);
        glTexCoord2d(1, 0);
        glVertex3d(x, y, z);

        glTexCoord2d(0, 0);
        glVertex3d(x, y, z-size);
        glTexCoord2d(0, 1);
        glVertex3d(x+size, y, z-size);
        glTexCoord2d(1, 1);
        glVertex3d(x+size, y, z);
        glTexCoord2d(1, 0);
        glVertex3d(x, y, z);

        glTexCoord2d(0, 0);
        glVertex3d(x, y+size, z);
        glTexCoord2d(0, 1);
        glVertex3d(x+size, y+size, z);
        glTexCoord2d(1, 1);
        glVertex3d(x+size, y+size, z-size);
        glTexCoord2d(1, 0);
        glVertex3d(x, y+size, z-size);
        glEnd();
        glEndList();
	}
	void initTexture(){
		if(id!=4){
			texture = glGenTextures();
			InputStream in = null;
			try {
	            in = new FileInputStream(texturePath);
	            PNGDecoder decoder = new PNGDecoder(in);
	            ByteBuffer buffer = BufferUtils.createByteBuffer(4 * decoder.getWidth() * decoder.getHeight());
	            decoder.decode(buffer, decoder.getWidth() * 4, Format.RGBA);
	            buffer.flip();
	            glBindTexture(GL_TEXTURE_2D, texture);
	            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
	            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, decoder.getWidth(), decoder.getHeight(), 0, GL_RGBA,GL_UNSIGNED_BYTE, buffer);
	            glBindTexture(GL_TEXTURE_2D, 0);
	        } catch (FileNotFoundException ex) {
	            System.err.println("Failed to find the texture files.");
	            ex.printStackTrace();
	            Display.destroy();
	            System.exit(1);
	        } catch (IOException ex) {
	            System.err.println("Failed to load the texture files.");
	            ex.printStackTrace();
	            Display.destroy();
	            System.exit(1);
	        } finally {
	            if (in != null) {
	                try {
	                    in.close();
	                } catch (IOException e) {
	                    e.printStackTrace();
	                }
	            }
	        }
		}else{
			texture=0;
		}
	}
}
