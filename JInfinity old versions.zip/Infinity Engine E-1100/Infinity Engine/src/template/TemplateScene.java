package template;

import engine.A_Scene;

//Eligible for complete removal.
//Quantity of sequences eligible for changes: Whole class.
//Description: Template of scene.
public class TemplateScene extends A_Scene{
	public TemplateScene(int ID){
		id=ID;
		create();
	}
	public void create(){
		entities.add(0,new TemplateEntity(0));
		entities.add(1,new TemplateCamera());
	}
}
