package engine;

import static engine.GL_Data.GL_FUNCTIONS;
import static engine.GL_Data.fogColor;
import static engine.GL_Data.fogFar;
import static engine.GL_Data.fogNear;
import static engine.GL_Data.fov;
import static engine.GL_Data.zFar;
import static engine.GL_Data.zNear;
import static org.lwjgl.opengl.GL11.GL_ALPHA_TEST;
import static org.lwjgl.opengl.GL11.GL_BACK;
import static org.lwjgl.opengl.GL11.GL_COLOR_BUFFER_BIT;
import static org.lwjgl.opengl.GL11.GL_CULL_FACE;
import static org.lwjgl.opengl.GL11.GL_DEPTH_BUFFER_BIT;
import static org.lwjgl.opengl.GL11.GL_FOG;
import static org.lwjgl.opengl.GL11.GL_FOG_COLOR;
import static org.lwjgl.opengl.GL11.GL_FOG_DENSITY;
import static org.lwjgl.opengl.GL11.GL_FOG_END;
import static org.lwjgl.opengl.GL11.GL_FOG_HINT;
import static org.lwjgl.opengl.GL11.GL_FOG_MODE;
import static org.lwjgl.opengl.GL11.GL_FOG_START;
import static org.lwjgl.opengl.GL11.GL_LINEAR;
import static org.lwjgl.opengl.GL11.GL_MODELVIEW;
import static org.lwjgl.opengl.GL11.GL_NICEST;
import static org.lwjgl.opengl.GL11.GL_ONE_MINUS_SRC_ALPHA;
import static org.lwjgl.opengl.GL11.GL_PERSPECTIVE_CORRECTION_HINT;
import static org.lwjgl.opengl.GL11.GL_PROJECTION;
import static org.lwjgl.opengl.GL11.GL_SRC_ALPHA;
import static org.lwjgl.opengl.GL11.glBlendFunc;
import static org.lwjgl.opengl.GL11.glClear;
import static org.lwjgl.opengl.GL11.glClearColor;
import static org.lwjgl.opengl.GL11.glCullFace;
import static org.lwjgl.opengl.GL11.glEnable;
import static org.lwjgl.opengl.GL11.glFog;
import static org.lwjgl.opengl.GL11.glFogf;
import static org.lwjgl.opengl.GL11.glFogi;
import static org.lwjgl.opengl.GL11.glHint;
import static org.lwjgl.opengl.GL11.glLoadIdentity;
import static org.lwjgl.opengl.GL11.glMatrixMode;
import static org.lwjgl.opengl.GL11.glViewport;
import static org.lwjgl.util.glu.GLU.gluPerspective;

import java.nio.FloatBuffer;

import org.lwjgl.BufferUtils;
import org.lwjgl.LWJGLException;
import org.lwjgl.Sys;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.Display;
import org.lwjgl.opengl.DisplayMode;
import org.lwjgl.opengl.GLContext;

//Quantity of sequences eligible for changes: 1.
//Description: core of engine. Contains primary methods and functions.
public class GL {
	public static int fps,fpsLimit;
	public static long lastFrame,lastFps;
	public static boolean showFps;
	public static boolean isResizable;
	public static boolean isVsync;
	public GL(String title, int width, int height, int fpsLimit, boolean isFullScreen, boolean isVsync, boolean isResizable, boolean showFps){
		try {
			GL.showFps=showFps;
			GL.fpsLimit=fpsLimit;
			GL.isResizable=isResizable;
			Display.setResizable(isResizable);
			if(isFullScreen){
				Display.setDisplayModeAndFullscreen(Display.getDesktopDisplayMode());
			}else{
                Display.setDisplayMode(new DisplayMode(width, height));
			}
            Display.setVSyncEnabled(isVsync);
            GL.isVsync=isVsync;
	        Display.setTitle(title);
	        Display.create();
	    } catch (LWJGLException e) {
	        e.printStackTrace();
            Display.destroy();
	        System.exit(0);
	    }
		if (!GLContext.getCapabilities().OpenGL11) {
            Display.destroy();
            System.exit(0);
        }
		if(isFullScreen){
			Mouse.setGrabbed(true);
		}else{
			Mouse.setGrabbed(false);
		}
		glViewport(0, 0, Display.getWidth(), Display.getHeight());
        glMatrixMode(GL_PROJECTION);
        glLoadIdentity();
        gluPerspective(fov, (float) Display.getWidth() / (float) Display.getHeight(), zNear, zFar);
        glMatrixMode(GL_MODELVIEW);
        glLoadIdentity();
	}
	public void initGL(){
		lastFps = getTime();
		for(int i = 0;i<GL_FUNCTIONS.length;i++){
			
			if(GL_FUNCTIONS[i]!=GL_FOG){
				glEnable(GL_FUNCTIONS[i]);
				//If you defined specific functions for GL you should add extra calls here
				//Add another if statement
				if(GL_FUNCTIONS[i]==GL_ALPHA_TEST){
			        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
			        glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);
				}
				if(GL_FUNCTIONS[i]==GL_CULL_FACE){
			        glCullFace(GL_BACK);
				}
				//
			}else if(GL_FUNCTIONS[i]==GL_FOG){
				glEnable(GL_FOG);{
			        FloatBuffer fogColours = BufferUtils.createFloatBuffer(4);
		            fogColours.put(new float[]{fogColor.r, fogColor.g, fogColor.b, fogColor.a});
		            glClearColor(fogColor.r, fogColor.g, fogColor.b, fogColor.a);
		            fogColours.flip();
		            glFog(GL_FOG_COLOR, fogColours);
		            glFogi(GL_FOG_MODE, GL_LINEAR);
		            glHint(GL_FOG_HINT, GL_NICEST);
		            glFogf(GL_FOG_START, fogNear);
		            glFogf(GL_FOG_END, fogFar);
		            glFogf(GL_FOG_DENSITY, 0.005f);
	            }
			}
		}
	}
	public void start(){
		initGL();
        System.out.println("Infinity engine E-1100. Created by _iLrax. Alpha build: 0.0.4, DC:103118");
        Scene_List.createScenes();
	}
	public static void setFullScreen(){
        if (Display.isFullscreen()){
        	setDisplay(Main.WIDTH,Main.HEIGHT,"",false);
        	glViewport(0, 0, Display.getWidth(), Display.getHeight());
        }else{
        	setDisplay(Main.WIDTH,Main.HEIGHT,"",true);
        	glViewport(0, 0, Display.getWidth(), Display.getHeight());
        }
	}
	public static void setDisplay(int Width, int Height,String Title,boolean IsFullScreen){
		try {
	        Display.setTitle(Title);
			if(IsFullScreen){
				Display.setDisplayModeAndFullscreen(Display.getDesktopDisplayMode());
			}else{
				Display.setResizable(isResizable);
                Display.setDisplayMode(new DisplayMode(Width, Height));
			}
            Display.setVSyncEnabled(isVsync);
	    } catch (LWJGLException e) {
	        e.printStackTrace();
            Display.destroy();
	        System.exit(0);
	    }
		if(IsFullScreen){
			Mouse.setGrabbed(true);
		}else{
			Mouse.setGrabbed(false);
		}
		if (!GLContext.getCapabilities().OpenGL11) {
            Display.destroy();
            System.exit(1);
        }
		glMatrixMode(GL_PROJECTION);
		glLoadIdentity();
		gluPerspective(fov, (float) Display.getWidth() / (float) Display.getHeight(), zNear, zFar);
		glMatrixMode(GL_MODELVIEW);
		glLoadIdentity();
	}
	public void prerender(){
		glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);
		updateFPS();
	}
	public void render(){
        if (isResizable) {
            if (Display.wasResized()) {
                glViewport(0, 0, Display.getWidth(), Display.getHeight());
                glMatrixMode(GL_PROJECTION);
                glLoadIdentity();
                gluPerspective(fov, (float) Display.getWidth() / (float) Display.getHeight(), zNear, zFar);
                glMatrixMode(GL_MODELVIEW);
                glLoadIdentity();
            }
        }
		Display.update();
		Display.sync(fpsLimit);
	}
	public static long getTime() {
        return (Sys.getTime() * 1000) / Sys.getTimerResolution();
    }
    public static int getDelta() {
        long currentTime = getTime();
        int delta = (int) (currentTime - lastFrame);
        lastFrame = getTime();
        return (delta);
    }
    public static void updateFPS() {
        if (getTime() - lastFps > 1000) {
        	if(showFps){
        		System.out.println("FPS: "+fps+".");
        	}
            fps = 0;
            lastFps += 1000;
        }
        fps++;
    }
	public static void exit(){
		Scene_List.destroyScenes();
        Display.destroy();
        System.exit(0);
	}
}
