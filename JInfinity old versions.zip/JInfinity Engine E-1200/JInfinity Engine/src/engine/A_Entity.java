package engine;

public class A_Entity {
	public int id;
	public A_Entity(){}
	public void destroy(){}
	public void logic(){}
	public void draw(){}
	public void sendTexture(int t){}
	public void refactor(float x,float y,float z,float sizeX,float sizeY,float sizeZ){}
	public void refactor(float x,float y,float sizeX,float sizeY){}
	public void refactor(){}
}
