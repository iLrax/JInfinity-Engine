package template3D;

import engine.A_Scene;

//Eligible for complete removal.
//Quantity of sequences eligible for changes: Whole class.
//Description: Template of scene.
public class TemplateScene3D extends A_Scene{
	public TemplateScene3D(int ID){
		id=ID;
		create();
	}
	public void create(){
		entities.add(new TemplateCamera3D());
		entities.add(new TemplateSpawner3D());
	}
}
