package template3D;

import static org.lwjgl.opengl.GL11.GL_TEXTURE_2D;
import static org.lwjgl.opengl.GL11.glBindTexture;
import static org.lwjgl.opengl.GL11.glDeleteTextures;

import java.util.ArrayList;
import java.util.List;

import engine.A_Entity;
import engine.A_Texture;

public class TemplateSpawner3D extends A_Entity{
	public List<A_Entity> entities = new ArrayList<A_Entity>();
	public static A_Texture[] textures;
	int xOff=-100, yOff=-100, zOff=-100;
	int xSize=200, ySize=200, zSize=200;
	float loading;
	public TemplateSpawner3D(){
		textures = new A_Texture[5];
		textures[1] = new A_Texture("res/TemplateTexture1.png");
		textures[2] = new A_Texture("res/TemplateTexture2.png");
		textures[3] = new A_Texture("res/TemplateTexture3.png");
		textures[4] = new A_Texture("res/TemplateTexture4.png");
		glBindTexture(GL_TEXTURE_2D, textures[1].texture);
		for(int i=0;i<xSize;i++){
			for(int j=0;j<ySize;j++){
				for(int k=0;k<zSize;k++){
					if(Math.random()*100<3){
						entities.add(new TemplateEntity3D((int)(Math.random()*xSize+xOff),(int)(Math.random()*ySize+yOff),(int)(Math.random()*zSize+zOff),1));
					}
				}
			}
			loading=i+1;
			loading=loading/xSize*100;
			System.out.println((int)loading+"% loading...");
		}
		for(A_Entity e:entities){
			e.sendTexture(textures[(int)(Math.random()*4+1)].texture);
			e.draw();
		}
		System.out.println("Loading completed.");
	}
	public void draw(){
		for(A_Entity e:entities){
			if(Math.random()*100<25){
				e.sendTexture(textures[(int)(Math.random()*4+1)].texture);
			}
			e.draw();
		}
	}
	public void destroy(){
		for(A_Entity e:entities){
			e.destroy();
		}
		for(A_Texture e:textures){
			if(e!=null){
				glDeleteTextures(e.texture);
			}
		}
	}
}
