package components;

import org.lwjgl.util.vector.Vector3f;

public class Transform2D {
	public Vector3f position = new Vector3f(0,0,0);
	public Vector3f rotation = new Vector3f(0,0,0);
	public Vector3f size = new Vector3f(1,1,0);
}
