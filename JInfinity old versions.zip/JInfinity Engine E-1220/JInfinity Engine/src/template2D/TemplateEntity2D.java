package template2D;

import static org.lwjgl.opengl.GL11.GL_COMPILE;
import static org.lwjgl.opengl.GL11.GL_QUADS;
import static org.lwjgl.opengl.GL11.GL_TEXTURE_2D;
import static org.lwjgl.opengl.GL11.glBegin;
import static org.lwjgl.opengl.GL11.glBindTexture;
import static org.lwjgl.opengl.GL11.glCallList;
import static org.lwjgl.opengl.GL11.glEnd;
import static org.lwjgl.opengl.GL11.glEndList;
import static org.lwjgl.opengl.GL11.glGenLists;
import static org.lwjgl.opengl.GL11.glNewList;
import static org.lwjgl.opengl.GL11.glTexCoord2d;
import static org.lwjgl.opengl.GL11.glVertex2f;

import org.lwjgl.opengl.Display;

import static org.lwjgl.input.Keyboard.*;

import components.Transform2D;
import engine.A_Entity;
import engine.A_Texture;
import engine.GL;

public class TemplateEntity2D extends A_Entity{
	public int mesh, delta, maxX, maxY;
	public Transform2D transform = new Transform2D();
	public A_Texture[] textures;
	public int texture,texturetmp;
	public double xspeed, yspeed;
	public boolean isLogoOnly=true;
	public TemplateEntity2D(float x, float y, float sizeX, float sizeY){
		textures = new A_Texture[7];
		textures[1] = new A_Texture("res/TemplateTexture1.png");
		textures[2] = new A_Texture("res/TemplateTexture2.png");
		textures[3] = new A_Texture("res/TemplateTexture3.png");
		textures[4] = new A_Texture("res/TemplateTexture4.png");
		textures[5] = new A_Texture("res/TemplateTexture5.png");
		textures[6] = new A_Texture("res/Logo2.png");
		glBindTexture(GL_TEXTURE_2D, textures[1].texture);
		texturetmp=textures[1].texture;
		x-=sizeX/2;
		y-=sizeY/2;
		maxX=Display.getWidth();
		maxY=Display.getHeight();
		xspeed=Math.random();
		yspeed=Math.random();
		refactor(x,y,sizeX,sizeY);
	}
	public void logic(){
		delta = GL.getDelta();
		while(next()){
			if(getEventKey()==KEY_F11&getEventKeyState()){
				GL.setFullScreen();
			}
			if(getEventKey()==KEY_ESCAPE&getEventKeyState()){
				GL.exit();
			}
			if(getEventKey()==KEY_SPACE&getEventKeyState()){
				xspeed*=1.15;
				yspeed*=1.15;
			}
			if(getEventKey()==KEY_LSHIFT&getEventKeyState()){
				xspeed/=1.15;
				yspeed/=1.15;
			}
		}
		if(transform.position.x<0){
			transform.position.x=0;
			xspeed=-xspeed;
			texture=(int)(Math.random()*4+1);
			while(texture==texturetmp){
				texture=(int)(Math.random()*4+1);
			}
			if(Math.random()*100<5){
				texture=5;
			}
			if(isLogoOnly){
				texture=6;
			}
			texturetmp=texture;
		}
		if(transform.position.y<0){
			transform.position.y=0;
			yspeed=-yspeed;
			texture=(int)(Math.random()*4+1);
			while(texture==texturetmp){
				texture=(int)(Math.random()*4+1);
			}
			if(Math.random()*100<5){
				texture=5;
			}
			if(isLogoOnly){
				texture=6;
			}
			texturetmp=texture;
		}
		if(transform.position.x>maxX-transform.size.x){
			transform.position.x=maxX-transform.size.x;
			xspeed=-xspeed;
			texture=(int)(Math.random()*4+1);
			while(texture==texturetmp){
				texture=(int)(Math.random()*4+1);
			}
			if(Math.random()*100<5){
				texture=5;
			}
			if(isLogoOnly){
				texture=6;
			}
			texturetmp=texture;
		}
		if(transform.position.y>maxY-transform.size.y){
			transform.position.y=maxY-transform.size.y;
			yspeed=-yspeed;
			texture=(int)(Math.random()*4+1);
			while(texture==texturetmp){
				texture=(int)(Math.random()*4+1);
			}
			if(Math.random()*100<5){
				texture=5;
			}
			if(isLogoOnly){
				texture=6;
			}
			texturetmp=texture;
		}
		transform.position.x+=xspeed*delta;
		transform.position.y+=yspeed*delta;
		refactor(transform.position.x,transform.position.y,transform.size.x,transform.size.y);
	}
	public void draw(){
		glBindTexture(GL_TEXTURE_2D, texture);
        glCallList(mesh);
	}
	public void refactor(float x, float y, float sizeX, float sizeY){
		transform.position.x=x;
		transform.position.y=y;
		transform.size.x=sizeX;
		transform.size.y=sizeY;
    	mesh = glGenLists(1);
    	glNewList(mesh, GL_COMPILE);
        glBegin(GL_QUADS);
        
        glTexCoord2d(0, 1);
        glVertex2f(x, y);
        glTexCoord2d(1, 1);
        glVertex2f(x+sizeX, y);
        glTexCoord2d(1, 0);
        glVertex2f(x+sizeX, y+sizeY);
        glTexCoord2d(0, 0);
        glVertex2f(x, y+sizeY);
        
        glEnd();
        glEndList();
	}
}
