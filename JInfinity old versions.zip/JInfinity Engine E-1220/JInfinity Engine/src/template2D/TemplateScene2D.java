package template2D;

import org.lwjgl.opengl.Display;

import engine.A_Scene;

public class TemplateScene2D extends A_Scene{
	public TemplateScene2D(int ID){
		id=ID;
		create();
	}
	public void create(){
		entities.add(new TemplateEntity2D((float)(Math.random()*Display.getWidth()),(float)(Math.random()*Display.getHeight()),67,125));
	}
}
