package template2D;

import static org.lwjgl.opengl.GL11.GL_COMPILE;
import static org.lwjgl.opengl.GL11.GL_QUADS;
import static org.lwjgl.opengl.GL11.GL_TEXTURE_2D;
import static org.lwjgl.opengl.GL11.glBegin;
import static org.lwjgl.opengl.GL11.glBindTexture;
import static org.lwjgl.opengl.GL11.glCallList;
import static org.lwjgl.opengl.GL11.glEnd;
import static org.lwjgl.opengl.GL11.glEndList;
import static org.lwjgl.opengl.GL11.glGenLists;
import static org.lwjgl.opengl.GL11.glNewList;
import static org.lwjgl.opengl.GL11.glTexCoord2d;
import static org.lwjgl.opengl.GL11.glVertex2f;

import components.Control2D;

import engine.A_Entity;
import engine.A_Texture;

public class TemplateEntity2Dv2 extends A_Entity{
	public int mesh, delta, maxX, maxY;
	public float speed;
	public Control2D control;
	public A_Texture texture;
	public TemplateEntity2Dv2(float x, float y, float sizeX, float sizeY, float maxSpeed, float acceleration){
		texture = new A_Texture("res/TemplateTexture1v2.png");
		glBindTexture(GL_TEXTURE_2D, texture.texture);
		control = new Control2D(x,y,sizeX,sizeY,maxSpeed,acceleration);
		refactor(x,y,sizeX,sizeY);
	}
	public void logic(){
		control.gameControlLogic();
		control.logic();
		refactor(control.position.x,control.position.y,control.size.x,control.size.y);
	}
	public void draw(){
		glBindTexture(GL_TEXTURE_2D, texture.texture);
        glCallList(mesh);
	}
	public void refactor(float x, float y, float sizeX, float sizeY){
    	mesh = glGenLists(1);
    	glNewList(mesh, GL_COMPILE);
        glBegin(GL_QUADS);
        
        glTexCoord2d(0, 1);
        glVertex2f(x, y);
        glTexCoord2d(1, 1);
        glVertex2f(x+sizeX, y);
        glTexCoord2d(1, 0);
        glVertex2f(x+sizeX, y+sizeY);
        glTexCoord2d(0, 0);
        glVertex2f(x, y+sizeY);
        
        glEnd();
        glEndList();
	}
}
