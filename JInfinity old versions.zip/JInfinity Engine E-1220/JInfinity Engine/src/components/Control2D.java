package components;

import static org.lwjgl.input.Keyboard.*;

import org.lwjgl.opengl.Display;
import org.lwjgl.util.vector.Vector3f;

import engine.GL;

public class Control2D {
	public Vector3f position = new Vector3f(0,0,0);
	public Vector3f rotation = new Vector3f(0,0,0);
	public Vector3f size = new Vector3f(1,1,0);
	public float xspeed,yspeed, speed, acceleration, speedmove;
	public int delta, maxX, maxY;
	public boolean idleX, idleY;
	public Control2D(float x,float y,float sizeX,float sizeY,float speed, float acceleration){
		x-=sizeX/2;
		y-=sizeY/2;
		position.x=x;
		position.y=y;
		size.x=sizeX;
		size.y=sizeY;
		xspeed=0;
		yspeed=0;
		idleX=true;
		idleY=true;
		this.speed=speed;
		this.acceleration=acceleration*0.01f;
		update();
	}
	public void update(){
		maxX=Display.getWidth();
		maxY=Display.getHeight();
	}
	public void logic(){
		delta = GL.getDelta();
		if(isKeyDown(KEY_W)){
			if(yspeed<=speed){
				yspeed+=acceleration*delta;
				idleY=false;
			}
			idleX=false;
		}else if(isKeyDown(KEY_S)){
			if(-yspeed<=speed){
				yspeed-=acceleration*delta;
				idleY=false;
			}
		}else{
			idleY=true;
		}
		if(isKeyDown(KEY_D)){
			if(xspeed<=speed){
				xspeed+=acceleration*delta;
				idleX=false;
			}
		}else if(isKeyDown(KEY_A)){
			if(-xspeed<=speed){
				xspeed-=acceleration*delta;
				idleX=false;
			}
		}else{
			idleX=true;
		}
		speedmove=(1-acceleration);
		if(idleX){
			if(speedmove<0){
				xspeed*=0;
			}else{
				xspeed*=(1-acceleration);
			}
		}
		if(idleY){
			if(speedmove<0){
				yspeed*=0;
			}else{
				yspeed*=(1-acceleration);
			}
		}
		if(xspeed<0&xspeed<-speed){
			xspeed=-speed;
		}
		if(xspeed>0&xspeed>speed){
			xspeed=speed;
		}
		if(yspeed<0&yspeed<-speed){
			yspeed=-speed;
		}
		if(yspeed>0&yspeed>speed){
			yspeed=speed;
		}
		if(Math.abs(xspeed)<0.0001){
			xspeed=0;
		}
		if(Math.abs(yspeed)<0.0001){
			yspeed=0;
		}
		position.x+=xspeed;
		position.y+=yspeed;
		if(position.x<0){
			position.x=0;
			xspeed=0;
		}
		if(position.y<0){
			position.y=0;
			yspeed=0;
		}
		if(position.x>maxX-size.x){
			position.x=maxX-size.x;
			xspeed=0;
		}
		if(position.y>maxY-size.y){
			position.y=maxY-size.y;
			yspeed=0;
		}
	}
	public void gameControlLogic(){
		while(next()){
			if(getEventKey()==KEY_F11&getEventKeyState()){
				GL.setFullScreen();
			}
			if(getEventKey()==KEY_ESCAPE&getEventKeyState()){
				GL.exit();
			}
		}
	}
}
