package engine;

import static engine.GL_Data.GL_FUNCTIONS_2D;
import static engine.GL_Data.GL_FUNCTIONS_3D;
import static engine.GL_Data.fogColor;
import static engine.GL_Data.fogFar;
import static engine.GL_Data.fogNear;
import static engine.GL_Data.fov;
import static engine.GL_Data.zFar;
import static engine.GL_Data.zNear;
import static org.lwjgl.opengl.GL11.GL_ALPHA_TEST;
import static org.lwjgl.opengl.GL11.GL_BACK;
import static org.lwjgl.opengl.GL11.GL_BLEND;
import static org.lwjgl.opengl.GL11.GL_COLOR_BUFFER_BIT;
import static org.lwjgl.opengl.GL11.GL_CULL_FACE;
import static org.lwjgl.opengl.GL11.GL_DEPTH_BUFFER_BIT;
import static org.lwjgl.opengl.GL11.GL_FOG;
import static org.lwjgl.opengl.GL11.GL_FOG_COLOR;
import static org.lwjgl.opengl.GL11.GL_FOG_DENSITY;
import static org.lwjgl.opengl.GL11.GL_FOG_END;
import static org.lwjgl.opengl.GL11.GL_FOG_HINT;
import static org.lwjgl.opengl.GL11.GL_FOG_MODE;
import static org.lwjgl.opengl.GL11.GL_FOG_START;
import static org.lwjgl.opengl.GL11.GL_LINEAR;
import static org.lwjgl.opengl.GL11.GL_MODELVIEW;
import static org.lwjgl.opengl.GL11.GL_NICEST;
import static org.lwjgl.opengl.GL11.GL_ONE_MINUS_SRC_ALPHA;
import static org.lwjgl.opengl.GL11.GL_PERSPECTIVE_CORRECTION_HINT;
import static org.lwjgl.opengl.GL11.GL_PROJECTION;
import static org.lwjgl.opengl.GL11.GL_SRC_ALPHA;
import static org.lwjgl.opengl.GL11.GL_TEXTURE_2D;
import static org.lwjgl.opengl.GL11.glBlendFunc;
import static org.lwjgl.opengl.GL11.glClear;
import static org.lwjgl.opengl.GL11.glClearColor;
import static org.lwjgl.opengl.GL11.glCullFace;
import static org.lwjgl.opengl.GL11.glEnable;
import static org.lwjgl.opengl.GL11.glFog;
import static org.lwjgl.opengl.GL11.glFogf;
import static org.lwjgl.opengl.GL11.glFogi;
import static org.lwjgl.opengl.GL11.glHint;
import static org.lwjgl.opengl.GL11.glLoadIdentity;
import static org.lwjgl.opengl.GL11.glMatrixMode;
import static org.lwjgl.opengl.GL11.glOrtho;
import static org.lwjgl.opengl.GL11.glViewport;
import static org.lwjgl.util.glu.GLU.gluPerspective;

import java.nio.FloatBuffer;

import org.lwjgl.BufferUtils;
import org.lwjgl.LWJGLException;
import org.lwjgl.Sys;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.Display;
import org.lwjgl.opengl.DisplayMode;
import org.lwjgl.opengl.GLContext;

//Quantity of sequences eligible for changes: 1.
//Description: core of engine. Contains primary methods and functions.
public class GL {
	public static int fps,fpsLimit;
	public static long lastFrame,lastFps;
	public static boolean showFps;
	public static boolean isResizable;
	public static boolean isVsync;
	public static boolean isEngine3D;
	public GL(String title, int width, int height, int fpsLimit, boolean isFullScreen, boolean isVsync, boolean isResizable, boolean showFps, boolean isEngine3D){
		if(!isEngine3D){
			isResizable=false;
		}
		try {
			if(isFullScreen){
				Display.setDisplayModeAndFullscreen(Display.getDesktopDisplayMode());
			}else{
                Display.setDisplayMode(new DisplayMode(width, height));
			}
			Display.setResizable(isResizable);
            Display.setVSyncEnabled(isVsync);
	        Display.setTitle(title);
	        Display.create();
	        GL.showFps=showFps;
			GL.fpsLimit=fpsLimit;
			GL.isResizable=isResizable;
			GL.isEngine3D=isEngine3D;
            GL.isVsync=isVsync;
	    } catch (LWJGLException e) {
	        System.exit(0);
	    }
		if (!GLContext.getCapabilities().OpenGL11) {
            exit();
        }
		if(isFullScreen){
			Mouse.setGrabbed(true);
		}else{
			Mouse.setGrabbed(false);
		}
		if(isEngine3D){
			glViewport(0, 0, Display.getWidth(), Display.getHeight());
	        glMatrixMode(GL_PROJECTION);
	        glLoadIdentity();
	        gluPerspective(fov, (float) Display.getWidth() / (float) Display.getHeight(), zNear, zFar);
	        glMatrixMode(GL_MODELVIEW);
	        glLoadIdentity();
		}else{
			glMatrixMode(GL_PROJECTION);
			glLoadIdentity();
			glOrtho(0, width, 0, height, 1, -1);
			glMatrixMode(GL_MODELVIEW);
			glLoadIdentity();
		}
	}
	public void initGL(){
		lastFps = getTime();
		if(isEngine3D){
			for(int i = 0;i<GL_FUNCTIONS_3D.length;i++){
				if(GL_FUNCTIONS_3D[i]!=GL_FOG){
					glEnable(GL_FUNCTIONS_3D[i]);
					//If you defined specific functions for GL you should add extra calls here
					//Add another if statement
					if(GL_FUNCTIONS_3D[i]==GL_ALPHA_TEST){
				        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
				        glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);
					}
					if(GL_FUNCTIONS_3D[i]==GL_CULL_FACE){
				        glCullFace(GL_BACK);
					}
					//
				}else if(GL_FUNCTIONS_3D[i]==GL_FOG){
					glEnable(GL_FOG);{
				        FloatBuffer fogColours = BufferUtils.createFloatBuffer(4);
			            fogColours.put(new float[]{fogColor.r, fogColor.g, fogColor.b, fogColor.a});
			            glClearColor(fogColor.r, fogColor.g, fogColor.b, fogColor.a);
			            fogColours.flip();
			            glFog(GL_FOG_COLOR, fogColours);
			            glFogi(GL_FOG_MODE, GL_LINEAR);
			            glHint(GL_FOG_HINT, GL_NICEST);
			            glFogf(GL_FOG_START, fogNear);
			            glFogf(GL_FOG_END, fogFar);
			            glFogf(GL_FOG_DENSITY, 0.005f);
		            }
				}
			}
		}else{
			for(int i = 0;i<GL_FUNCTIONS_2D.length;i++){
				if(GL_FUNCTIONS_2D[i]==GL_BLEND){
					glEnable(GL_BLEND);
					glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
				}
				if(GL_FUNCTIONS_2D[i]==GL_TEXTURE_2D){
					glEnable(GL_TEXTURE_2D);
				}
			}
		}
	}
	public void start(){
		initGL();
        Scene_List.createScenes(isEngine3D);
        System.out.println("JInfinity engine E-1220. Created by _iLrax. Alpha build: 1.1.0, DC:112018");
        System.out.println("Product is under Creative Commons license Attribution 4.0 International (CC BY 4.0)");
	}
	public static void setFullScreen(){
        if (Display.isFullscreen()){
        	setDisplay(Main.WIDTH,Main.HEIGHT,Display.getTitle(),false);
        	if(isEngine3D){
        		glViewport(0, 0, Display.getWidth(), Display.getHeight());
        	}else{
        		glViewport(0, 0, engine.Main.WIDTH,engine.Main.HEIGHT);
        	}
        }else{
        	setDisplay(Main.WIDTH,Main.HEIGHT,Display.getTitle(),true);
        	if(isEngine3D){
        		glViewport(0, 0, Display.getWidth(), Display.getHeight());
        	}else{
        		glViewport(0, 0, Display.getDesktopDisplayMode().getWidth(),Display.getDesktopDisplayMode().getHeight());
        	}
        }
	}
	public static void setDisplay(int Width, int Height,String Title,boolean IsFullScreen){
		try {
	        Display.setTitle(Title);
			if(IsFullScreen){
				Display.setDisplayModeAndFullscreen(Display.getDesktopDisplayMode());
			}else{
				Display.setResizable(isResizable);
                Display.setDisplayMode(new DisplayMode(engine.Main.WIDTH, engine.Main.HEIGHT));
			}
            Display.setVSyncEnabled(isVsync);
	    } catch (LWJGLException e) {
	        exit();
	    }
		if(IsFullScreen){
			Mouse.setGrabbed(true);
		}else{
			Mouse.setGrabbed(false);
		}
		if (!GLContext.getCapabilities().OpenGL11) {
            exit();
        }
		if(isEngine3D){
			glMatrixMode(GL_PROJECTION);
			glLoadIdentity();
			gluPerspective(fov, (float) Display.getWidth() / (float) Display.getHeight(), zNear, zFar);
			glMatrixMode(GL_MODELVIEW);
			glLoadIdentity();
		}else{
			if(IsFullScreen){
				glOrtho(0, Display.getDesktopDisplayMode().getWidth(), 0, Display.getDesktopDisplayMode().getHeight(), 1, -1);
				glMatrixMode(GL_MODELVIEW);
				glLoadIdentity();
			}else{
				glOrtho(0, engine.Main.WIDTH, 0, engine.Main.HEIGHT, 1, -1);
				glMatrixMode(GL_MODELVIEW);
				glLoadIdentity();
			}
		}
	}
	public void prerender(){
		if(isEngine3D){
			glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);
		}else{
			glClear(GL_COLOR_BUFFER_BIT);
		}
		updateFPS();
	}
	public void render(){
        if (isResizable) {
            if (Display.wasResized()) {
            	if(isEngine3D){
	                glViewport(0, 0, Display.getWidth(), Display.getHeight());
	                glMatrixMode(GL_PROJECTION);
	                glLoadIdentity();
	                gluPerspective(fov, (float) Display.getWidth() / (float) Display.getHeight(), zNear, zFar);
	                glMatrixMode(GL_MODELVIEW);
	                glLoadIdentity();
            	}else{
                	glMatrixMode(GL_PROJECTION);
	                glLoadIdentity();
	    			glOrtho(0, Display.getWidth(), 0, Display.getHeight(), 1, -1);
	    			glMatrixMode(GL_MODELVIEW);
	                glLoadIdentity();
            	}
            }
        }
		Display.update();
		Display.sync(fpsLimit);
	}
	public static long getTime() {
        return (Sys.getTime() * 1000) / Sys.getTimerResolution();
    }
    public static int getDelta() {
        long currentTime = getTime();
        int delta = (int) (currentTime - lastFrame);
        lastFrame = getTime();
        return (delta);
    }
    public static void updateFPS() {
        if (getTime() - lastFps > 1000) {
        	if(showFps){
        		System.out.println("FPS: "+fps+".");
        	}
            fps = 0;
            lastFps += 1000;
        }
        fps++;
    }
	public static void exit(){
		Scene_List.destroyScenes();
        Display.destroy();
        System.exit(0);
	}
}
