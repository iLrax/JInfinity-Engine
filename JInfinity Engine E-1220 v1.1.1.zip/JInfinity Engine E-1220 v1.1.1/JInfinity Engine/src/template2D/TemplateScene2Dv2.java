package template2D;

import org.lwjgl.opengl.Display;

import engine.A_Scene;

public class TemplateScene2Dv2  extends A_Scene{
	public TemplateScene2Dv2(int ID){
		id=ID;
		create();
	}
	public void create(){
		entities.add(new TemplateEntity2Dv2((float)(Display.getWidth()/2),(float)(Display.getHeight()/2),100,100,100,3));
	}
}
