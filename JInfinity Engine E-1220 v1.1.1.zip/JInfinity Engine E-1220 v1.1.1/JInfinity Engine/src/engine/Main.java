package engine;

import org.lwjgl.opengl.Display;

//Quantity of sequences eligible for changes: 1.
//Description: main class of engine. Is used only to start and run main code. Also defines specifications of window.
public class Main {
	public static GL gl;
	public static String TITLE;
	public static int WIDTH,HEIGHT,FPS_LIMIT;
	public static boolean IS_FULLSCREEN,IS_VSYNC,IS_RESIZABLE,IS_FPS_SHOWED,IS_ENGINE_3D;
	Main(){
		//Define here specifications of window
		//
		TITLE = "JInfinity Engine E-1220";
		WIDTH = 1280;
		HEIGHT = 720;
		FPS_LIMIT = 60;
		IS_FULLSCREEN = false;
		IS_VSYNC = true;
		IS_RESIZABLE = true;
		IS_FPS_SHOWED = false;
		IS_ENGINE_3D = true;
		//
		gl = new GL(TITLE,WIDTH,HEIGHT,FPS_LIMIT,IS_FULLSCREEN,IS_VSYNC,IS_RESIZABLE,IS_FPS_SHOWED,IS_ENGINE_3D);
		gl.start();
		while (!Display.isCloseRequested()) {
			gl.prerender();
			Scene_List.updateScenes();
			gl.render();
        }
        GL.exit();
	}
	public static void main(String[] args){
		new Main();
	}
}
