package engine;

//Quantity of sequences eligible for changes: 0.
//Description: base class for entities.
public class A_Entity {
	public int id;
	public A_Entity(){}
	public void destroy(){}
	public void logic(){}
	public void draw(){}
}
