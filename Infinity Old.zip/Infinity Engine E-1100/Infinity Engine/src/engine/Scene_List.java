package engine;

import java.util.ArrayList;
import java.util.List;

import template.TemplateScene;

//Quantity of sequences eligible for changes: 1.
//Description: control class for scenes. All scenes should be set up here.
public class Scene_List {
	public static List<A_Scene> sceneList = new ArrayList<A_Scene>();
	public static int currentSceneId=0;
	public static void createScenes(){
		//You must define your scenes here
		//Set currentSceneId only once at the end of sequence
		Scene_List.sceneList.add(new TemplateScene(77));
		Scene_List.currentSceneId=77;
		//
	}
	public static void switchScene(int newId){
		sceneList.get(currentSceneId).destroy();
		currentSceneId = newId;
	}
	public static void updateScenes(){
		for(int i=0;i<sceneList.size();i++){
			if(sceneList.get(i).id==currentSceneId){
				sceneList.get(i).logic();
				sceneList.get(i).draw();
			}
		}
	}
	public static void destroyScenes(){
		for(A_Scene e:sceneList){
			e.destroy();
		}
	}
}
