package template3D;

import static org.lwjgl.opengl.GL11.GL_COMPILE;
import static org.lwjgl.opengl.GL11.GL_QUADS;
import static org.lwjgl.opengl.GL11.GL_TEXTURE_2D;
import static org.lwjgl.opengl.GL11.glBegin;
import static org.lwjgl.opengl.GL11.glBindTexture;
import static org.lwjgl.opengl.GL11.glCallList;
import static org.lwjgl.opengl.GL11.glDeleteLists;
import static org.lwjgl.opengl.GL11.glEnd;
import static org.lwjgl.opengl.GL11.glEndList;
import static org.lwjgl.opengl.GL11.glGenLists;
import static org.lwjgl.opengl.GL11.glNewList;
import static org.lwjgl.opengl.GL11.glTexCoord2d;
import static org.lwjgl.opengl.GL11.glVertex3d;

import components.Transform3D;

import engine.A_Entity;

//Eligible for complete removal.
//Quantity of sequences eligible for changes: Whole class.
//Description: Template of entity.
public class TemplateEntity3D extends A_Entity{
	String texturePath;
	public int mesh, texture, displayRange=53, drawCooldown=(int)(Math.random()*0);
	public Transform3D transform = new Transform3D();
	public boolean ToDraw=false;
	public float a;
	public TemplateEntity3D(float X, float Y, float Z, float size){
		refactor(X,Y,Z,size);
	}
	public void sendTexture(int tex){
		if(drawCooldown==0){
			texture=tex;
		}
	}
	public void draw(){
		if(drawCooldown==0){
			if(!(Math.pow(-(TemplateCamera3D.transform.position.x)-transform.position.x, 2)+
			Math.pow(-(TemplateCamera3D.transform.position.y)-transform.position.y, 2)+
			Math.pow(-(TemplateCamera3D.transform.position.z)-transform.position.z, 2)>Math.pow(displayRange,2))){
				ToDraw=true;
			}else{
				ToDraw=false;
			}
			drawCooldown=(int)(Math.random()*500);
		}else{
			drawCooldown--;
		}
		if(ToDraw){
			glBindTexture(GL_TEXTURE_2D, texture);
	        glCallList(mesh);
		}
	}
	public void destroy(){
        glDeleteLists(mesh, 1);
	}
	public void refactor(float x,float y,float z,float size){
		transform.position.x=x;
		transform.position.y=y;
		transform.position.z=z;
		transform.size.x=size;
		transform.size.y=size;
		transform.size.z=size;
    	a = size;
    	mesh = glGenLists(1);
		glNewList(mesh, GL_COMPILE);
        glBegin(GL_QUADS);
        
        glTexCoord2d(0, 1);
        glVertex3d(x, y, z+a);
        glTexCoord2d(1, 1);
        glVertex3d(x+size, y, z+a);
        glTexCoord2d(1, 0);
        glVertex3d(x+size, y+size, z+a);
        glTexCoord2d(0, 0);
        glVertex3d(x, y+size, z+a);
        
        glTexCoord2d(0, 0);
        glVertex3d(x+size, y, z+a);
        glTexCoord2d(1, 0);
        glVertex3d(x+size, y, z);
        glTexCoord2d(1, 1);
        glVertex3d(x+size, y+size, z);
        glTexCoord2d(0, 1);
        glVertex3d(x+size, y+size, z+a);
		
        glTexCoord2d(0, 1);
        glVertex3d(x, y+size, z);
        glTexCoord2d(1, 1);
        glVertex3d(x+size, y+size, z);
        glTexCoord2d(1, 0);
        glVertex3d(x+size, y, z);
        glTexCoord2d(0, 0);
        glVertex3d(x, y, z);

        glTexCoord2d(0, 0);
        glVertex3d(x, y+size, z+a);
        glTexCoord2d(1, 0);
        glVertex3d(x, y+size, z);
        glTexCoord2d(1, 1);
        glVertex3d(x, y, z);
        glTexCoord2d(0, 1);
        glVertex3d(x, y, z+a);

        glTexCoord2d(0, 0);
        glVertex3d(x, y, z);
        glTexCoord2d(1, 0);
        glVertex3d(x+size, y, z);
        glTexCoord2d(1, 1);
        glVertex3d(x+size, y, z+a);
        glTexCoord2d(0, 1);
        glVertex3d(x, y, z+a);

        glTexCoord2d(0, 0);
        glVertex3d(x, y+size, z+a);
        glTexCoord2d(1, 0);
        glVertex3d(x+size, y+size, z+a);
        glTexCoord2d(1, 1);
        glVertex3d(x+size, y+size, z);
        glTexCoord2d(0, 1);
        glVertex3d(x, y+size, z);
        
        glEnd();
        glEndList();
	}
}
