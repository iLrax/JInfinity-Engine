package template3D;

import static org.lwjgl.opengl.GL11.glLoadIdentity;
import static org.lwjgl.opengl.GL11.glRotatef;
import static org.lwjgl.opengl.GL11.glTranslatef;

import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;
import org.lwjgl.util.vector.Vector3f;

import components.Transform3D;

import engine.A_Entity;
import engine.GL;

//Eligible for complete removal.
//Quantity of sequences eligible for changes: Whole class.
//Description: Template of Main camera.
public class TemplateCamera3D extends A_Entity{
	public static Transform3D transform = new Transform3D();
	int movingSpeed = 7, mouseSpeed = 2, maxLookUp = 90, maxLookDown = -90, delta;
	public void logic(){
		delta = GL.getDelta();
		if (Mouse.isGrabbed()) {
            float mouseDX = Mouse.getDX() * mouseSpeed * 0.16f;
            float mouseDY = Mouse.getDY() * mouseSpeed * 0.16f;
            if (transform.rotation.y + mouseDX >= 360) {
            	transform.rotation.y = transform.rotation.y + mouseDX - 360;
            } else if (transform.rotation.y + mouseDX < 0) {
            	transform.rotation.y = 360 - transform.rotation.y + mouseDX;
            } else {
            	transform.rotation.y += mouseDX;
            }
            if (transform.rotation.x - mouseDY >= maxLookDown && transform.rotation.x - mouseDY <= maxLookUp) {
            	transform.rotation.x += -mouseDY;
            } else if (transform.rotation.x - mouseDY < maxLookDown) {
            	transform.rotation.x = maxLookDown;
            } else if (transform.rotation.x - mouseDY > maxLookUp) {
            	transform.rotation.x = maxLookUp;
            }
        }
		boolean keyUp = Keyboard.isKeyDown(Keyboard.KEY_UP)|Keyboard.isKeyDown(Keyboard.KEY_W);
        boolean keyDown = Keyboard.isKeyDown(Keyboard.KEY_DOWN)|Keyboard.isKeyDown(Keyboard.KEY_S);
        boolean keyLeft = Keyboard.isKeyDown(Keyboard.KEY_LEFT)|Keyboard.isKeyDown(Keyboard.KEY_A);
        boolean keyRight = Keyboard.isKeyDown(Keyboard.KEY_RIGHT)|Keyboard.isKeyDown(Keyboard.KEY_D);
        boolean flyUp = Keyboard.isKeyDown(Keyboard.KEY_SPACE);
        boolean flyDown = Keyboard.isKeyDown(Keyboard.KEY_LSHIFT);
        if (keyUp && keyRight && !keyLeft && !keyDown) {
            float angle = transform.rotation.y + 45;
            Vector3f newPosition = new Vector3f(transform.position);
            float hypotenuse = (movingSpeed * 0.0002f) * delta;
            float adjacent = hypotenuse * (float) Math.cos(Math.toRadians(angle));
            float opposite = (float) (Math.sin(Math.toRadians(angle)) * hypotenuse);
            newPosition.z += adjacent;
            newPosition.x -= opposite;
            transform.position.z = newPosition.z;
            transform.position.x = newPosition.x;
        }
        if (keyUp && keyLeft && !keyRight && !keyDown) {
            float angle = transform.rotation.y - 45;
            Vector3f newPosition = new Vector3f(transform.position);
            float hypotenuse = (movingSpeed * 0.0002f) * delta;
            float adjacent = hypotenuse * (float) Math.cos(Math.toRadians(angle));
            float opposite = (float) (Math.sin(Math.toRadians(angle)) * hypotenuse);
            newPosition.z += adjacent;
            newPosition.x -= opposite;
            transform.position.z = newPosition.z;
            transform.position.x = newPosition.x;
        }
        if (keyUp && !keyLeft && !keyRight && !keyDown) {
            float angle = transform.rotation.y;
            Vector3f newPosition = new Vector3f(transform.position);
            float hypotenuse = (movingSpeed * 0.0002f) * delta;
            float adjacent = hypotenuse * (float) Math.cos(Math.toRadians(angle));
            float opposite = (float) (Math.sin(Math.toRadians(angle)) * hypotenuse);
            newPosition.z += adjacent;
            newPosition.x -= opposite;
            transform.position.z = newPosition.z;
            transform.position.x = newPosition.x;
        }
        if (keyDown && keyLeft && !keyRight && !keyUp) {
            float angle = transform.rotation.y - 135;
            Vector3f newPosition = new Vector3f(transform.position);
            float hypotenuse = (movingSpeed * 0.0002f) * delta;
            float adjacent = hypotenuse * (float) Math.cos(Math.toRadians(angle));
            float opposite = (float) (Math.sin(Math.toRadians(angle)) * hypotenuse);
            newPosition.z += adjacent;
            newPosition.x -= opposite;
            transform.position.z = newPosition.z;
            transform.position.x = newPosition.x;
        }
        if (keyDown && keyRight && !keyLeft && !keyUp) {
            float angle = transform.rotation.y + 135;
            Vector3f newPosition = new Vector3f(transform.position);
            float hypotenuse = (movingSpeed * 0.0002f) * delta;
            float adjacent = hypotenuse * (float) Math.cos(Math.toRadians(angle));
            float opposite = (float) (Math.sin(Math.toRadians(angle)) * hypotenuse);
            newPosition.z += adjacent;
            newPosition.x -= opposite;
            transform.position.z = newPosition.z;
            transform.position.x = newPosition.x;
        }
        if (keyDown && !keyUp && !keyLeft && !keyRight) {
            float angle = transform.rotation.y;
            Vector3f newPosition = new Vector3f(transform.position);
            float hypotenuse = -(movingSpeed * 0.0002f) * delta;
            float adjacent = hypotenuse * (float) Math.cos(Math.toRadians(angle));
            float opposite = (float) (Math.sin(Math.toRadians(angle)) * hypotenuse);
            newPosition.z += adjacent;
            newPosition.x -= opposite;
            transform.position.z = newPosition.z;
            transform.position.x = newPosition.x;
        }
        if (keyLeft && !keyRight && !keyUp && !keyDown) {
            float angle = transform.rotation.y - 90;
            Vector3f newPosition = new Vector3f(transform.position);
            float hypotenuse = (movingSpeed * 0.0002f) * delta;
            float adjacent = hypotenuse * (float) Math.cos(Math.toRadians(angle));
            float opposite = (float) (Math.sin(Math.toRadians(angle)) * hypotenuse);
            newPosition.z += adjacent;
            newPosition.x -= opposite;
            transform.position.z = newPosition.z;
            transform.position.x = newPosition.x;
        }
        if (keyRight && !keyLeft && !keyUp && !keyDown) {
            float angle = transform.rotation.y + 90;
            Vector3f newPosition = new Vector3f(transform.position);
            float hypotenuse = (movingSpeed * 0.0002f) * delta;
            float adjacent = hypotenuse * (float) Math.cos(Math.toRadians(angle));
            float opposite = (float) (Math.sin(Math.toRadians(angle)) * hypotenuse);
            newPosition.z += adjacent;
            newPosition.x -= opposite;
            transform.position.z = newPosition.z;
            transform.position.x = newPosition.x;
        }
        if (flyUp && !flyDown) {
            double newPositionY = (movingSpeed * 0.0002) * delta;
            transform.position.y -= newPositionY;
        }
        if (flyDown && !flyUp) {
            double newPositionY = (movingSpeed * 0.0002) * delta;
            transform.position.y += newPositionY;
        }
        while (Mouse.next()) {
            if (Mouse.isButtonDown(0)) {
                Mouse.setGrabbed(!Mouse.isGrabbed());
            }
        }
        while (Keyboard.next()) {
            if (Keyboard.isKeyDown(Keyboard.KEY_F11)) {
                GL.setFullScreen();
            }
            if (Keyboard.isKeyDown(Keyboard.KEY_ESCAPE)) {
            	GL.exit();
            }
        }
        glLoadIdentity();
		glRotatef(transform.rotation.x, 1, 0, 0);
        glRotatef(transform.rotation.y, 0, 1, 0);
        glRotatef(transform.rotation.z, 0, 0, 1);
        glTranslatef(transform.position.x, transform.position.y, transform.position.z);
	}
}
