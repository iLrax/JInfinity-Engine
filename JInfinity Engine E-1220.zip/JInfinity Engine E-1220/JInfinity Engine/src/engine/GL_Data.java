package engine;

import static org.lwjgl.opengl.GL11.GL_ALPHA_TEST;
import static org.lwjgl.opengl.GL11.GL_BLEND;
import static org.lwjgl.opengl.GL11.GL_CULL_FACE;
import static org.lwjgl.opengl.GL11.GL_DEPTH_TEST;
import static org.lwjgl.opengl.GL11.GL_FOG;
import static org.lwjgl.opengl.GL11.GL_TEXTURE_2D;

import org.newdawn.slick.Color;

//Quantity of sequences eligible for changes: 2.
//Description: database of parameters. Determine here used functions of GL and arguments for them.
public class GL_Data {
	//This parameters are applied to GL functions. Change them freely.
	public static Color fogColor = new Color(0.95f, 0.99f, 1f, 0.5f);
	//public static Color fogColor = new Color(0.5f, 0.1f, 0.1f, 0.5f);
	public static float zNear = 0.001f,zFar = 33f,fogNear = 14f,fogFar = 33f;
	public static int fov = 77;
	//
	//Array of used GL functions.
	//To add new just insert new element.
	public static int[] GL_FUNCTIONS_3D = {
		GL_DEPTH_TEST,
		GL_TEXTURE_2D,
		GL_BLEND,
		GL_ALPHA_TEST,
		GL_CULL_FACE,
		GL_FOG
	};
	public static int[] GL_FUNCTIONS_2D = {
		GL_TEXTURE_2D,
		GL_BLEND,
	};
	//
}
