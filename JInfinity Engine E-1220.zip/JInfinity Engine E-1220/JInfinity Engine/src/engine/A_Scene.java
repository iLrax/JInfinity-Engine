package engine;

import java.util.ArrayList;
import java.util.List;

//Quantity of sequences eligible for changes: 0.
//Description: base class for scenes.
public class A_Scene {
	public int id;
	public List<A_Entity> entities = new ArrayList<A_Entity>();
	public void destroy(){
		for(A_Entity e:entities){
			e.destroy();
		}
	}
	public void logic(){
		for(A_Entity e:entities){
			e.logic();
		}
	}
	public void draw(){
		for(A_Entity e:entities){
			e.draw();
		}
	}
	public void create(){}
}
